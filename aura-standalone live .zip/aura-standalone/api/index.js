// Entry point Vercel uses to run this app as a serverless function.
// It just re-exports the same Express app defined in server.js — all
// the actual routes, access-code check, and rate limiting live there.
module.exports = require('../server.js');
